package com.wallan.multimediacamera.library.camera.contract;

import com.wallan.base.app.library.BasePresenter;
import com.wallan.base.app.library.BaseView;

/**
 * Created by hanxu on 2018/6/5.
 */

public interface CameraMainContract {

    interface View extends BaseView {

    }

    interface Presenter extends BasePresenter {

    }
}
