package com.wallan.multimediacamera.library.bean;

/**
 * Created by hanxu on 2018/5/29.
 */

public interface SwitchValue {
    String OPEN = "open";
    String CLOSE = "close";
}
